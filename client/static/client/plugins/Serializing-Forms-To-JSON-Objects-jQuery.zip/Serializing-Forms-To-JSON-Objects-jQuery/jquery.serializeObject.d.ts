
interface JQuery {
    serializeObject(): { [index: string]: string|string[] }
}
